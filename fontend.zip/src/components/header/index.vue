<template>
    <Nav />
</template>

<script>
import Nav from "./Nav";
export default {
  components: {
    Nav,
  },
};
</script>
