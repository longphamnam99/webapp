<template>
  <div class="container">
    <div class="row register-form">
      <div class="col">
        <div class="box-register">
          <form v-on:submit.prevent="onSubmit">
            <div class="form-group p-2">
              <div class="alert alert-danger">Đăng nhập không chính xác.</div>
            </div>
            <div class="form-group p-2">
              <label for="username">Tên đăng nhập</label>
              <input
                v-model="username"
                type="text"
                class="form-control"
                placeholder="Tên đăng nhập"
              />
            </div>
            <div class="form-group p-2">
              <label for="password">Mật khẩu</label>
              <input
                v-model="password"
                type="password"
                class="form-control"
                placeholder="Nhập mật khẩu"
              />
            </div>
             <div class="form-group p-2">
              <label for="password">Nhập lại khẩu</label>
              <input
                v-model="retype_password"
                type="password"
                class="form-control"
                placeholder="Nhập lại mật khẩu"
              />
            </div>
            <div class="d-flex justify-content-center">
              <button type="submit" class="btn btn-primary">Đăng nhập</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    onSubmit() {
      let username = this.username;
      let password = this.password;
      let retype_password = this.retype_password;
    },
  },
};
</script>

<style scoped>
.register-form {
  padding: 3% 20% 3% 20%;
}
.box-register {
  padding: 0 20% 0 20%;
}
</style>
