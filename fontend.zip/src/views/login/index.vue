<template>
  <div class="container">
    <div class="row login-form">
      <div class="col">
        <div class="box-login">
          <div class="card p-3">
            <form v-on:submit.prevent="onSubmit">
              <div class="form-group p-2" v-if="error.show">
                <div class="alert alert-danger">{{ error.message }}</div>
              </div>
              <div class="form-group p-2">
                <label for="username">Tên đăng nhập</label>
                <input
                  v-model="post.username"
                  type="text"
                  class="form-control"
                  placeholder="Tên đăng nhập"
                />
              </div>
              <div class="form-group p-2">
                <label for="password">Mật khẩu</label>
                <input
                  v-model="post.password"
                  type="password"
                  class="form-control"
                  placeholder="Nhập mật khẩu"
                />
              </div>
              <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary">Đăng nhập</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import UserService from "@/api/user";

export default {
  data() {
    return {
      post: {
        username: "",
        password: "",
      },
      error: {
        show: false,
        message: "Vui lòng nhập tên đăng nhập hoặc mật khẩu."
      },
    };
  },
  methods: {
    onSubmit() {
      let username = this.post.username;
      let password = this.post.password;
      if (username == null || password == null || username == "" || password == "") {
        this.error.show = true;
        return;
      }
      let data = {
          username: username,
          password: password,
        };
        UserService.login(data).then(res => {
          console.log(res)
        });
    },
  },
};
</script>

<style scoped>
.login-form {
  padding: 3% 20% 3% 20%;
}
.box-login {
  padding: 0 20% 0 20%;
}
</style>
