
export function auth() {
  return {
    'Content-Type': 'application/json',
    'token': 'abc'
  }
}
